const CATALOG_JOB_KEY = "catalogImportJob";
const DISCOVERY_KEY = "catalogDiscoverySchedule";
const REPAIR_KEY = "catalogContentRepairSchedule";
let catalogWorkerActive = false;
let continuousStarting = false;
const DEFAULT_DISCOVERY_PAGES = ["home-garden", "kitchen", "sporting-goods", "tools", "office-products", "pet-supplies", "toys-and-games", "arts-crafts", "beauty", "electronics"].flatMap((category) => [1, 2].map((page) => `https://www.amazon.com/Best-Sellers/zgbs/${category}?pg=${page}`));

async function continueDiscovery() {
  if (continuousStarting) return;
  continuousStarting = true;
  try {
    const settings = (await chrome.storage.local.get(DISCOVERY_KEY))[DISCOVERY_KEY];
    const job = await catalogJob();
    const workload = await workloadState();
    if (!settings?.enabled || !settings.continuous || ["running", "paused", "error"].includes(job?.status) || workload.paused || (workload.used || 0) >= workload.dailyLimit || (workload.nextAt || 0) > Date.now()) return;
    const visits = settings.pageVisits || {};
    // One pass per category page per day, not endless re-reading of saved ASINs.
    const page = settings.pages.find((url) => !visits[url] || Date.now() - visits[url] >= 24 * 60 * 60 * 1000);
    if (!page) return;
    await beginCatalogImport([], [page], 1000);
    const latest = (await chrome.storage.local.get(DISCOVERY_KEY))[DISCOVERY_KEY];
    if (latest?.enabled && latest.continuous) await chrome.storage.local.set({ [DISCOVERY_KEY]: { ...latest, pageVisits: { ...(latest.pageVisits || {}), [page]: Date.now() } } });
  } finally { continuousStarting = false; }
}

async function catalogJob() { return (await chrome.storage.local.get(CATALOG_JOB_KEY))[CATALOG_JOB_KEY]; }
async function saveCatalogJob(job, resume = false) {
  const current = await catalogJob();
  if (!resume && current?.startedAt === job.startedAt && current.status === "cancelled" && job.status !== "cancelled") return;
  await chrome.storage.local.set({ [CATALOG_JOB_KEY]: { ...job, updatedAt: Date.now() } });
}

function validBestsellerUrl(value) {
  try { const url = new URL(value); return url.protocol === "https:" && /^(www\.)?amazon\.com$/.test(url.hostname) && /\/zgbs(?:\/|$)|\/Best-Sellers/i.test(url.pathname); } catch { return false; }
}

async function catalogRpc(tabId, payload) {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { type: "CATALOG_IMPORT_RPC", payload });
      if (response?.ok) return response.result;
      if (response && !response.notReady) throw new Error(response.error || "Catalog request failed.");
    } catch (error) {
      if (!/receiving end|connection|message port/i.test(error.message)) throw error;
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  throw new Error("Sign in to Sellfinity as an administrator and open the import page.");
}

async function readCatalogPage(url, type, job) {
  const permit = await reserveAmazonPage();
  if (!permit.ok) { const error = new Error(permit.reason); error.workloadPause = true; throw error; }
  const tab = await chrome.tabs.create({ url, active: false });
  await saveCatalogJob({ ...job, productTabId: tab.id });
  let preserveTab = false;
  try {
    if (job.repair) {
      const candidate = job.candidates[job.cursor];
      if (candidate?.id) await catalogRpc(job.adminTabId, { operation: "contentCheck", id: candidate.id });
    }
    let reason = "Amazon page could not be read.";
    for (let attempt = 0; attempt < 30; attempt++) {
      if ((await catalogJob())?.status !== "running") throw new Error("Import stopped.");
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { type });
        if (response?.ok) return response.result;
        reason = response?.error || reason;
        if (/CAPTCHA/i.test(reason)) throw new Error(reason);
      } catch (error) { if (/CAPTCHA|Import stopped/i.test(error.message)) throw error; }
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    throw new Error(reason);
  } catch (error) {
    preserveTab = /CAPTCHA|verification|access denied|sign.in/i.test(error.message);
    if (preserveTab) { await pauseAmazonWork("Amazon verification required for catalog import. Checking the existing tab hourly; manual verification may still be needed.", true, tab.id); error.workloadPause = true; }
    throw error;
  } finally { if (!preserveTab) try { await chrome.tabs.remove(tab.id); } catch { /* Already closed. */ } }
}

async function beginCatalogImport(candidates = [], pages = [], limit = 100, product = null, repair = false) {
  const current = await catalogJob();
  if (current?.status === "running") throw new Error("A catalog import is already running. Stop it before starting another.");
  if ((await runStatuses()).some((run) => run.status === "running" && run.mode === "PRICE")) throw new Error("Finish or stop the live price check before importing products.");
  let adminTab = null;
  if (current?.adminTabId) {
    try { const previous = await chrome.tabs.get(current.adminTabId); if (previous.url === "https://www.sellfinity.app/admin/arbitrage/import") adminTab = previous; } catch { /* Recreate a closed source tab. */ }
  }
  if (!adminTab) adminTab = await chrome.tabs.create({ url: "https://www.sellfinity.app/admin/arbitrage/import", active: false });
  await saveCatalogJob({ status: "running", adminTabId: adminTab.id, candidates, pages, pageCursor: 0, cursor: 0, limit, added: 0, updated: 0, skipped: 0, failed: 0, errors: [], product, repair, startedAt: Date.now() });
  void processCatalogImport();
}

async function processCatalogImport() {
  if (catalogWorkerActive) return;
  catalogWorkerActive = true;
  try {
    let job = await catalogJob();
    if (job?.status !== "running") return;
    if (job.productTabId) {
      try { await chrome.tabs.remove(job.productTabId); } catch { /* Previous browser session ended. */ }
      job.productTabId = null;
    }
    try { await chrome.tabs.get(job.adminTabId); }
    catch {
      const tab = await chrome.tabs.create({ url: "https://www.sellfinity.app/admin/arbitrage/import", active: false });
      job.adminTabId = tab.id;
    }
    await catalogRpc(job.adminTabId, { operation: "filter", asins: [] });
    if (job.repair && !job.prepared) {
      const queue = await catalogRpc(job.adminTabId, { operation: "repairQueue", limit: job.limit });
      job.candidates = queue.candidates; job.prepared = true;
      await saveCatalogJob(job);
    }
    if (job.product) {
      const saved = await catalogRpc(job.adminTabId, { operation: "save", rows: [job.product] });
      await saveCatalogJob({ ...job, status: "complete", added: saved.added, updated: saved.updated || 0, skipped: saved.skipped, product: null });
      return;
    }
    while (job.status === "running" && (job.repair ? job.cursor < job.limit : job.added < job.limit)) {
      if (job.cursor >= job.candidates.length) {
        if (job.pageCursor >= job.pages.length) break;
        const page = job.pages[job.pageCursor];
        const found = await readCatalogPage(page, "CAPTURE_BESTSELLER_PAGE", job);
        const seen = new Set(job.candidates.map((row) => row.asin));
        job.candidates.push(...found.filter((row) => !seen.has(row.asin)));
        job.pageCursor++;
        await saveCatalogJob(job);
        continue;
      }
      // Filter a page-sized group before opening product tabs. Existing ASINs
      // never trigger redundant product reads or paid provider requests.
      const next = job.candidates.slice(job.cursor, job.cursor + 50);
      const result = job.repair ? { existing: [] } : await catalogRpc(job.adminTabId, { operation: "filter", asins: next.map((row) => row.asin) });
      const existing = new Set(result.existing);
      for (const candidate of next) {
        if ((await catalogJob())?.status !== "running") return;
        if (job.repair ? job.cursor >= job.limit : job.added >= job.limit) break;
        if (existing.has(candidate.asin)) { job.skipped++; job.cursor++; await saveCatalogJob(job); continue; }
        try {
          const product = await readCatalogPage(candidate.amazonUrl, "CAPTURE_CATALOG_PRODUCT", job);
          // A redirected variant cannot inherit another ASIN's bestseller rank.
          if (product.asin !== candidate.asin) throw new Error("Amazon redirected to a different ASIN. Review this product manually.");
          const saved = await catalogRpc(job.adminTabId, { operation: "save", rows: [{ ...product, source: "BESTSELLER_BROWSER", bestsellerRank: candidate.bestsellerRank, bestsellerCategory: candidate.bestsellerCategory, bestsellerUrl: candidate.bestsellerUrl }] });
          job.added += saved.added; job.updated = (job.updated || 0) + (saved.updated || 0); job.skipped += saved.skipped;
        } catch (error) {
          if (error.workloadPause || /CAPTCHA|administrator|Catalog save|Catalog request|Import stopped/i.test(error.message)) throw error;
          job.failed++; job.errors = [...job.errors, `${candidate.asin}: ${error.message}`].slice(-20);
        }
        if ((await catalogJob())?.status !== "running") return;
        job.cursor++; job.productTabId = null;
        await saveCatalogJob(job);
      }
    }
    await saveCatalogJob({ ...job, status: "complete", detail: job.repair ? `${job.cursor} incomplete products checked. Missing content may still need manual review.` : job.added >= job.limit ? "Target reached" : "Selected pages exhausted" });
  } catch (error) {
    const job = await catalogJob();
    if (job?.status === "running") await saveCatalogJob({ ...job, status: error.workloadPause ? "paused" : "error", detail: error.message });
  } finally { catalogWorkerActive = false; }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!["GET_CATALOG_IMPORT_STATUS", "IMPORT_CURRENT_AMAZON", "IMPORT_CURRENT_BESTSELLERS", "STOP_CATALOG_IMPORT", "SAVE_DISCOVERY_SCHEDULE", "RESUME_CATALOG_IMPORT", "SAVE_CONTENT_REPAIR_SCHEDULE", "REPAIR_CATALOG_CONTENT", "START_CONTINUOUS_DISCOVERY"].includes(message?.type)) return;
  void (async () => {
    try {
      if (message.type === "GET_CATALOG_IMPORT_STATUS") {
        sendResponse({ ok: true, job: await catalogJob(), schedule: (await chrome.storage.local.get(DISCOVERY_KEY))[DISCOVERY_KEY], repairSchedule: (await chrome.storage.local.get(REPAIR_KEY))[REPAIR_KEY] }); return;
      }
      if (message.type === "STOP_CATALOG_IMPORT") {
        const settings = (await chrome.storage.local.get(DISCOVERY_KEY))[DISCOVERY_KEY];
        if (settings?.continuous) await chrome.storage.local.set({ [DISCOVERY_KEY]: { ...settings, enabled: false, continuous: false } });
        const job = await catalogJob();
        if (job) {
          await saveCatalogJob({ ...job, status: "cancelled" });
          if (job.productTabId) try { await chrome.tabs.remove(job.productTabId); } catch { /* Already closed. */ }
        }
      } else if (message.type === "START_CONTINUOUS_DISCOVERY") {
        const job = await catalogJob();
        if (["running", "paused", "error"].includes(job?.status)) throw new Error("Finish, stop or resume the current import first. Verification pauses cannot be bypassed.");
        // Random order is for category variety, not an anti-detection mechanism.
        const pages = [...DEFAULT_DISCOVERY_PAGES];
        for (let i = pages.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pages[i], pages[j]] = [pages[j], pages[i]]; }
        const saved = (await chrome.storage.local.get(DISCOVERY_KEY))[DISCOVERY_KEY];
        await chrome.storage.local.set({ [DISCOVERY_KEY]: { enabled: true, continuous: true, time: "00:00", pages, limit: 1000, pageVisits: saved?.pageVisits || {} } });
        await continueDiscovery();
      } else if (message.type === "RESUME_CATALOG_IMPORT") {
        const job = await catalogJob();
        if (job && job.status !== "running") { await saveCatalogJob({ ...job, status: "running" }, true); void processCatalogImport(); }
      } else if (message.type === "REPAIR_CATALOG_CONTENT") {
        await beginCatalogImport([], [], Math.max(1, Math.min(1000, Number(message.limit) || 100)), null, true);
      } else if (message.type === "SAVE_CONTENT_REPAIR_SCHEDULE") {
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(message.time)) throw new Error("Choose a valid time.");
        await chrome.storage.local.set({ [REPAIR_KEY]: { enabled: Boolean(message.enabled), time: message.time, limit: Math.max(1, Math.min(1000, Number(message.limit) || 100)) } });
      } else if (message.type === "SAVE_DISCOVERY_SCHEDULE") {
        const pages = (message.pages || []).filter(Boolean);
        if (!pages.length || pages.length > 20 || pages.some((url) => !validBestsellerUrl(url))) throw new Error("Enter 1–20 Amazon Best Sellers category/page URLs.");
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(message.time)) throw new Error("Choose a valid time.");
        await chrome.storage.local.set({ [DISCOVERY_KEY]: { enabled: Boolean(message.enabled), time: message.time, pages, limit: Math.max(1, Math.min(1000, Number(message.limit) || 100)) } });
      } else {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.url || !/^https:\/\/(www\.)?amazon\.com\//.test(tab.url)) throw new Error("Open an Amazon product or Best Sellers page first.");
        const response = await chrome.tabs.sendMessage(tab.id, { type: message.type === "IMPORT_CURRENT_AMAZON" ? "CAPTURE_CATALOG_PRODUCT" : "CAPTURE_BESTSELLER_PAGE" });
        if (!response?.ok) throw new Error(response?.error || "Reload the Amazon tab after reloading the extension.");
        await beginCatalogImport(message.type === "IMPORT_CURRENT_BESTSELLERS" ? response.result : [], [], 1000, message.type === "IMPORT_CURRENT_AMAZON" ? response.result : null);
      }
      sendResponse({ ok: true });
    } catch (error) { sendResponse({ ok: false, error: error.message }); }
  })();
  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== "catalog-discovery") return;
  void (async () => {
    const job = await catalogJob();
    if (job?.status === "paused" || (await workloadState()).paused) return;
    if (job?.status === "running") { await processCatalogImport(); return; }
    const repair = (await chrome.storage.local.get(REPAIR_KEY))[REPAIR_KEY];
    const localNow = new Date();
    if (repair?.enabled && repair.lastDay !== localDay(localNow)) {
      const [hour, minute] = repair.time.split(":").map(Number);
      if (localNow.getHours() * 60 + localNow.getMinutes() >= hour * 60 + minute) {
        try {
          await beginCatalogImport([], [], repair.limit, null, true);
          await chrome.storage.local.set({ [REPAIR_KEY]: { ...repair, lastDay: localDay(localNow) } });
        } catch { /* Retry when a price check or import finishes. */ }
        return;
      }
    }
    const settings = (await chrome.storage.local.get(DISCOVERY_KEY))[DISCOVERY_KEY];
    if (settings?.continuous) { await continueDiscovery().catch(() => {}); return; }
    const now = new Date();
    if (!settings?.enabled || settings.lastDay === localDay(now)) return;
    const [hours, minutes] = settings.time.split(":").map(Number);
    if (now.getHours() * 60 + now.getMinutes() < hours * 60 + minutes) return;
    try {
      await beginCatalogImport([], settings.pages, settings.limit);
      await chrome.storage.local.set({ [DISCOVERY_KEY]: { ...settings, lastDay: localDay(now) } });
    } catch { /* Wait until any existing price-check run finishes. */ }
  })();
});
void chrome.alarms.create("catalog-discovery", { periodInMinutes: 1 });
