(() => {
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "CATALOG_IMPORT_RPC") return;
    if (document.documentElement.dataset.sellfinityCatalogImportReady !== "true") { sendResponse({ ok: false, notReady: true }); return; }
    const requestId = crypto.randomUUID();
    const receive = (event) => {
      if (event.detail?.requestId !== requestId) return;
      clearTimeout(timer);
      document.removeEventListener("sellfinity:catalog-import-result", receive);
      sendResponse(event.detail);
    };
    const timer = setTimeout(() => {
      document.removeEventListener("sellfinity:catalog-import-result", receive);
      sendResponse({ ok: false, error: "Catalog save timed out. Sign in as an administrator and retry." });
    }, 60000);
    document.addEventListener("sellfinity:catalog-import-result", receive);
    document.dispatchEvent(new CustomEvent("sellfinity:catalog-import-request", { detail: { requestId, ...message.payload } }));
    return true;
  });
  const TOAST_ID = "sellfinity-tracking-helper-toast";

  function toast(message, tone = "info") {
    document.getElementById(TOAST_ID)?.remove();
    const element = document.createElement("div");
    element.id = TOAST_ID;
    element.textContent = message;
    Object.assign(element.style, {
      position: "fixed",
      right: "20px",
      bottom: "20px",
      zIndex: "2147483647",
      maxWidth: "390px",
      padding: "12px 16px",
      borderRadius: "10px",
      background: tone === "error" ? "#991b1b" : tone === "success" ? "#047857" : "#3730a3",
      color: "white",
      font: "600 13px/1.45 system-ui, sans-serif",
      boxShadow: "0 12px 30px rgba(15, 23, 42, .25)"
    });
    document.documentElement.appendChild(element);
    setTimeout(() => element.remove(), 8_000);
  }

  function setReactInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    setter?.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  const saveQueue = [];
  let savingQueue = false;
  let bulkProgress = null;
  let amazonPriceProgress = null;

  function wait(milliseconds) {
    return new Promise((resolve) => setTimeout(resolve, milliseconds));
  }

  async function saveQueuedTracking() {
    if (savingQueue) return;
    savingQueue = true;
    while (saveQueue.length) {
      const orderId = saveQueue.shift();
      for (let attempt = 0; attempt < 120; attempt++) {
        const input = document.querySelector(`input[data-order-id="${CSS.escape(orderId)}"]`);
        const row = input?.closest("tr");
        const button = [...(row?.querySelectorAll("button") || [])]
          .find((candidate) => /save tracking|save & mark shipped/i.test(candidate.textContent || ""));
        if (button && !button.disabled) {
          button.click();
          break;
        }
        await wait(500);
      }
      await wait(1000);
    }
    savingQueue = false;
  }

  function queueAutomaticSave(orderId) {
    if (!orderId || saveQueue.includes(orderId)) return;
    saveQueue.push(orderId);
    saveQueuedTracking();
  }

  function bulkTrackingRequests(suppliedRequests = []) {
    const discovered = [...document.querySelectorAll("a")]
      .filter((anchor) => /open amazon tracking/i.test(anchor.textContent || ""))
      .flatMap((anchor) => {
        const input = anchor.closest("tr")?.querySelector('input[aria-label^="Tracking number for "]');
        if (!(input instanceof HTMLInputElement) || !input.dataset.orderId) return [];
        return [{
          orderId: input.dataset.orderId,
          inputLabel: input.getAttribute("aria-label"),
          amazonUrl: anchor.href
        }];
      });
    const supplied = suppliedRequests.flatMap((request) => {
      if (!request?.orderId || !request.amazonUrl) return [];
      const input = document.querySelector(`input[data-order-id="${CSS.escape(request.orderId)}"]`);
      return [{
        orderId: request.orderId,
        inputLabel: input?.getAttribute("aria-label") || null,
        amazonUrl: request.amazonUrl
      }];
    });
    return [...new Map([...supplied, ...discovered].map((request) => [request.orderId, request])).values()];
  }

  function reportBulkProgress(status = "running") {
    if (!bulkProgress) return;
    document.dispatchEvent(new CustomEvent("sellfinity:tracking-helper-progress", { detail: {
      status,
      total: bulkProgress.total,
      processed: bulkProgress.processed,
      found: bulkProgress.found
    } }));
  }

  function finishBulkItem(found) {
    if (!bulkProgress) return;
    bulkProgress.processed = Math.min(bulkProgress.total, bulkProgress.processed + 1);
    if (found) bulkProgress.found += 1;
    reportBulkProgress(bulkProgress.processed >= bulkProgress.total ? "complete" : "running");
  }

  function reportAmazonPriceProgress(status = "running") {
    if (!amazonPriceProgress) return;
    document.dispatchEvent(new CustomEvent("sellfinity:amazon-price-helper-progress", { detail: {
      status,
      total: amazonPriceProgress.total,
      processed: amazonPriceProgress.processed,
      found: amazonPriceProgress.found
    } }));
  }

  function finishAmazonPriceItem(found) {
    if (!amazonPriceProgress) return;
    amazonPriceProgress.processed = Math.min(amazonPriceProgress.total, amazonPriceProgress.processed + 1);
    if (found) amazonPriceProgress.found += 1;
    reportAmazonPriceProgress(amazonPriceProgress.processed >= amazonPriceProgress.total ? "complete" : "running");
  }

  function amazonPriceRequests(suppliedRequests = []) {
    if (Array.isArray(suppliedRequests) && suppliedRequests.length) return suppliedRequests;
    const grouped = new Map();
    for (const anchor of document.querySelectorAll('a[data-amazon-price-check="true"]')) {
      const orderId = anchor.dataset.orderId;
      const requestKey = anchor.dataset.requestKey;
      if (!orderId || !requestKey || !anchor.href) continue;
      const current = grouped.get(requestKey);
      if (current) current.orderIds.push(orderId);
      else grouped.set(requestKey, { requestKey, amazonUrl: anchor.href, orderIds: [orderId] });
    }
    return [...grouped.values()];
  }

  document.addEventListener("sellfinity:bulk-tracking-refresh", (event) => {
    const requests = bulkTrackingRequests(event.detail?.requests || []);
    if (!requests.length) return;
    // Acknowledge the request before the background worker opens any tabs so
    // Sellfinity never mistakes a slow Amazon launch for a missing helper.
    bulkProgress = { total: requests.length, processed: 0, found: 0 };
    reportBulkProgress();
    chrome.runtime.sendMessage({ type: "BEGIN_BULK_TRACKING_REQUEST", requests })
      .then((result) => {
        if (result?.queued) {
          bulkProgress.total = result.queued;
          reportBulkProgress();
          toast(`Checking ${result.queued} Amazon tracking page${result.queued === 1 ? "" : "s"}…`);
        }
      })
      .catch(() => {
        reportBulkProgress("error");
        bulkProgress = null;
        toast("The tracking helper could not start the automatic check.", "error");
      });
  });

  document.addEventListener("sellfinity:bulk-amazon-price-check", (event) => {
    const requests = amazonPriceRequests(event.detail?.requests);
    if (!requests.length) return;
    // Report immediately. Opening several signed-in Amazon tabs can take more
    // than the UI's helper-detection window even though the extension is fine.
    amazonPriceProgress = { total: requests.length, processed: 0, found: 0 };
    reportAmazonPriceProgress();
    chrome.runtime.sendMessage({ type: "BEGIN_BULK_AMAZON_PRICE_CHECK", requests })
      .then((result) => {
        if (result?.queued) {
          amazonPriceProgress.total = result.queued;
          reportAmazonPriceProgress();
          toast(`Checking ${result.queued} unique Amazon product${result.queued === 1 ? "" : "s"} for current price and shipping…`);
        }
      })
      .catch(() => {
        reportAmazonPriceProgress("error");
        amazonPriceProgress = null;
        toast("The Amazon price checker could not start.", "error");
      });
  });

  document.addEventListener("sellfinity:stop-amazon-price-check", () => {
    chrome.runtime.sendMessage({ type: "CANCEL_BULK_REQUESTS", mode: "PRICE" })
      .then((result) => toast(`Amazon price check stopped. ${result?.cancelled || 0} remaining request${result?.cancelled === 1 ? "" : "s"} cancelled.`))
      .catch(() => toast("The Amazon price check could not be stopped.", "error"));
  });

  document.addEventListener("sellfinity:stop-tracking-check", () => {
    chrome.runtime.sendMessage({ type: "CANCEL_BULK_REQUESTS", mode: "TRACKING" })
      .then((result) => toast(`Tracking check stopped. ${result?.cancelled || 0} remaining request${result?.cancelled === 1 ? "" : "s"} cancelled.`))
      .catch(() => toast("The tracking check could not be stopped.", "error"));
  });

  document.addEventListener("click", (event) => {
    const anchor = event.target instanceof Element
      ? event.target.closest("a")
      : null;
    if (!anchor || !/open amazon tracking/i.test(anchor.textContent || "")) return;
    const row = anchor.closest("tr");
    const input = row?.querySelector('input[aria-label^="Tracking number for "]');
    if (!(input instanceof HTMLInputElement)) {
      toast("Sellfinity could not locate this order's tracking field.", "error");
      return;
    }
    const requestId = crypto.randomUUID();
    chrome.runtime.sendMessage({
      type: "BEGIN_TRACKING_REQUEST",
      requestId,
      inputLabel: input.getAttribute("aria-label"),
      orderId: input.dataset.orderId,
      amazonUrl: anchor.href
    }).then(() => toast("Amazon tracking opened. Waiting for a carrier tracking number…"))
      .catch(() => toast("The tracking helper could not start. Reload this page and try again.", "error"));
  }, true);

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "FILL_TRACKING") {
      const inputs = [...document.querySelectorAll('input[aria-label^="Tracking number for "]')];
      const input = message.orderId
        ? document.querySelector(`input[data-order-id="${CSS.escape(message.orderId)}"]`)
        : inputs.find((candidate) => candidate.getAttribute("aria-label") === message.inputLabel);
      if (!(input instanceof HTMLInputElement)) {
        if (message.autoSave) finishBulkItem(false);
        else toast("Tracking was found, but the original fulfillment row is no longer visible.", "error");
        return;
      }
      setReactInputValue(input, message.trackingNumber);
      document.dispatchEvent(new CustomEvent("sellfinity:tracking-filled", { detail: {
        orderId: message.orderId || input.dataset.orderId,
        trackingNumber: message.trackingNumber,
        carrier: message.carrier
      } }));
      if (message.autoSave) queueAutomaticSave(message.orderId || input.dataset.orderId);
      if (message.autoSave) finishBulkItem(true);
      input.scrollIntoView({ behavior: "smooth", block: "center" });
      input.focus();
      input.style.outline = "3px solid #34d399";
      setTimeout(() => { input.style.outline = ""; }, 5_000);
      toast(message.autoSave
        ? `${message.carrier || "Carrier"} tracking ${message.trackingNumber} found and queued to save.`
        : `${message.carrier || "Carrier"} tracking ${message.trackingNumber} filled. Review it, then save.`, "success");
    }
    if (message?.type === "TRACKING_LOOKUP_FAILED") {
      if (message.autoSave) finishBulkItem(false);
      else toast(message.reason || "No supported tracking number was found.", "error");
    }
    if (message?.type === "FILL_AMAZON_PRICE") {
      document.dispatchEvent(new CustomEvent("sellfinity:amazon-price-found", { detail: {
        orderIds: message.orderIds,
        unitPriceCents: message.unitPriceCents,
        shippingCents: message.shippingCents
      } }));
      finishAmazonPriceItem(true);
      const shipping = message.shippingCents === null || message.shippingCents === undefined
        ? "shipping was not shown and was left unchanged"
        : message.shippingCents === 0 ? "free shipping" : `$${(message.shippingCents / 100).toFixed(2)} shipping`;
      toast(`Amazon price $${(message.unitPriceCents / 100).toFixed(2)} found · ${shipping}.`, "success");
    }
    if (message?.type === "AMAZON_PRICE_LOOKUP_FAILED") {
      if (message.unavailable && Array.isArray(message.orderIds) && message.orderIds.length) {
        document.dispatchEvent(new CustomEvent("sellfinity:amazon-product-unavailable", { detail: {
          orderIds: message.orderIds,
          reason: message.reason
        } }));
      }
      finishAmazonPriceItem(false);
      toast(message.reason || "Amazon did not show a current price for this product.", "error");
    }
    if (message?.type === "BULK_RUN_CANCELLED") {
      if (!message.mode || message.mode === "PRICE") {
        reportAmazonPriceProgress("cancelled");
        amazonPriceProgress = null;
      }
      if (!message.mode || message.mode === "TRACKING") {
        reportBulkProgress("cancelled");
        bulkProgress = null;
      }
    }
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "START_DAILY_USER_SYNC") {
      if (document.documentElement.dataset.sellfinityUserSyncReady !== "true") { sendResponse({ ok: false }); return; }
      document.dispatchEvent(new CustomEvent("sellfinity:daily-user-sync"));
      sendResponse({ ok: true });
      return true;
    }
    if (message?.type !== "START_DAILY_ADMIN_CHECK") return;
    if (document.documentElement.dataset.sellfinityAdminCheckerReady !== "true") {
      sendResponse({ ok: false });
      return;
    }
    document.dispatchEvent(new CustomEvent("sellfinity:daily-admin-check", { detail: { resume: Boolean(message.resume) } }));
    sendResponse({ ok: true });
    return true;
  });
  document.addEventListener("sellfinity:daily-check-complete", (event) => {
    const detail = event.detail;
    chrome.runtime.sendMessage({ type: "DAILY_CHECK_COMPLETE", detail: detail ? `${detail.updated} updated · ${detail.unavailable} unavailable · ${detail.failed} could not be verified` : "No remaining catalog products to check" }).catch(() => {});
  });
  document.addEventListener("sellfinity:daily-check-error", () => {
    chrome.runtime.sendMessage({ type: "DAILY_CHECK_COMPLETE", failed: true, detail: "Catalog check could not start or save its results. Open the admin catalog to review the error, then Run now." }).catch(() => {});
  });
  document.addEventListener("sellfinity:daily-user-progress", (event) => {
    const result = event.detail;
    chrome.runtime.sendMessage({ type: "DAILY_USER_PROGRESS", detail: `${result.completed}/${result.total} processed · ${result.updated} updated · ${result.ended} delisted · ${result.needsAttention} need review · ${result.errors} errors` }).catch(() => {});
  });
  document.addEventListener("sellfinity:daily-user-complete", (event) => {
    const result = event.detail;
    chrome.runtime.sendMessage({ type: "DAILY_CHECK_COMPLETE", failed: result.errors > 0, detail: `${result.updated} updated · ${result.ended} delisted · ${result.needsAttention} need review · ${result.errors} errors` }).catch(() => {});
  });
  document.addEventListener("sellfinity:daily-user-error", () => {
    chrome.runtime.sendMessage({ type: "DAILY_CHECK_COMPLETE", failed: true, detail: "User sync failed. Open Listings to review the error and reconnect eBay if needed." }).catch(() => {});
  });
})();
