const PENDING_KEY = "pendingTrackingRequests";
const STATUS_KEY = "bulkRunStatuses";
// Workload pauses can span days. Queues are retained locally for seven days.
const MAX_REQUEST_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const FINISHED_STATUS_AGE_MS = 60 * 60 * 1000;
const MAX_BULK_TABS = 1;
importScripts("workload.js");
importScripts("daily-check.js");
importScripts("catalog-import.js");

async function runStatuses() {
  const stored = await chrome.storage.local.get(STATUS_KEY);
  const now = Date.now();
  return (stored[STATUS_KEY] || []).filter((status) => {
    const age = now - (status.updatedAt || status.startedAt);
    return age < (["running", "paused"].includes(status.status) ? MAX_REQUEST_AGE_MS : FINISHED_STATUS_AGE_MS);
  });
}

async function saveRunStatuses(statuses) {
  await chrome.storage.local.set({ [STATUS_KEY]: statuses });
}

function requestMode(request) {
  return request.mode === "PRICE" ? "PRICE" : "TRACKING";
}

async function startRun(sourceTabId, mode, total) {
  const statuses = (await runStatuses()).filter((status) => !(status.sourceTabId === sourceTabId && status.mode === mode));
  const now = Date.now();
  statuses.push({ sourceTabId, mode, total, completed: 0, found: 0, errors: 0, status: "running", startedAt: now, updatedAt: now });
  await saveRunStatuses(statuses);
}

async function advanceRun(sourceTabId, mode, found) {
  const statuses = await runStatuses();
  const status = statuses.find((candidate) => candidate.sourceTabId === sourceTabId && candidate.mode === mode);
  if (!status || status.status !== "running") return;
  status.completed = Math.min(status.total, status.completed + 1);
  if (found) status.found += 1;
  else status.errors += 1;
  if (status.completed >= status.total) status.status = "complete";
  status.updatedAt = Date.now();
  await saveRunStatuses(statuses);
}

async function cancelRuns(sourceTabId, mode) {
  const requests = await pendingRequests();
  const cancelled = requests.filter((request) => request.bulk && (!sourceTabId || request.sourceTabId === sourceTabId) && (!mode || requestMode(request) === mode));
  const cancelledIds = new Set(cancelled.map((request) => request.requestId));
  await savePending(requests.filter((request) => !cancelledIds.has(request.requestId)));
  const tabIds = [...new Set(cancelled.map((request) => request.destinationTabId).filter(Boolean))];
  if (tabIds.length) {
    try { await chrome.tabs.remove(tabIds); } catch { /* Some helper tabs may already be closed. */ }
  }
  const statuses = await runStatuses();
  for (const status of statuses) {
    if ((!sourceTabId || status.sourceTabId === sourceTabId) && (!mode || status.mode === mode) && status.status === "running") {
      status.status = "cancelled";
      status.updatedAt = Date.now();
    }
  }
  await saveRunStatuses(statuses);
  for (const tabId of new Set(cancelled.map((request) => request.sourceTabId))) {
    try { await chrome.tabs.sendMessage(tabId, { type: "BULK_RUN_CANCELLED", mode }); } catch { /* The Sellfinity tab may have closed. */ }
  }
  return cancelled.length;
}

async function pendingRequests() {
  const stored = await chrome.storage.local.get(PENDING_KEY);
  const now = Date.now();
  return (stored[PENDING_KEY] || []).filter((request) => now - request.createdAt < MAX_REQUEST_AGE_MS);
}

async function savePending(requests) {
  await chrome.storage.local.set({ [PENDING_KEY]: requests });
}

async function notifySource(request, message) {
  try {
    await chrome.tabs.sendMessage(request.sourceTabId, {
      ...message,
      inputLabel: request.inputLabel,
      orderId: request.orderId,
      requestId: request.requestId
    });
    if (!request.bulk) await chrome.tabs.update(request.sourceTabId, { active: true });
  } catch {
    // The originating Sellfinity tab may have been closed or reloaded.
  }
}

async function processBulkQueue(sourceTabId) {
  if (queueProcessing) return;
  queueProcessing = true;
  try {
  try { await chrome.tabs.get(sourceTabId); } catch { return; }
  const catalog = await catalogJob();
  if (catalog?.status === "running") return;
  const initialRequests = await pendingRequests();
  const active = initialRequests.filter((request) => request.bulk && request.sourceTabId === sourceTabId && request.destinationTabId !== null);
  const waiting = initialRequests.filter((request) => request.bulk && request.sourceTabId === sourceTabId && request.destinationTabId === null);
  const available = Math.max(0, MAX_BULK_TABS - active.length);
  for (const request of waiting.slice(0, available)) {
    const permit = await reserveAmazonPage();
    if (!permit.ok) return;
    let openedTabId = null;
    try {
      // Register the destination before loading Amazon. A fast cached page can
      // report tracking immediately; previously that response raced the final
      // storage write and was discarded because its tab was still unknown.
      const tab = await chrome.tabs.create({ url: "about:blank", active: false });
      openedTabId = tab.id || null;
      const latest = await pendingRequests();
      const liveRequest = latest.find((candidate) => candidate.requestId === request.requestId);
      // Stop can be clicked while this tab is being created. Do not restore a
      // cancelled request or continue its Amazon navigation.
      if (!liveRequest) {
        if (openedTabId) await chrome.tabs.remove(openedTabId);
        continue;
      }
      liveRequest.destinationTabId = openedTabId;
      await savePending(latest);
      if ((await workloadState()).paused) {
        liveRequest.destinationTabId = null;
        await savePending(latest);
        if (openedTabId) await chrome.tabs.remove(openedTabId);
        return;
      }
      if (tab.id) {
        if (requestMode(request) === "PRICE") await notifySource(request, { type: "AMAZON_CHECK_ATTEMPTED", orderIds: request.orderIds });
        await chrome.tabs.update(tab.id, { url: request.amazonUrl });
      }
    } catch {
      const isPrice = requestMode(request) === "PRICE";
      await notifySource(request, isPrice
        ? { type: "AMAZON_PRICE_LOOKUP_FAILED", reason: "The Amazon product page could not be opened.", orderIds: request.orderIds }
        : { type: "TRACKING_LOOKUP_FAILED", reason: "Amazon tracking could not be opened." });
      await advanceRun(request.sourceTabId, requestMode(request), false);
      await noteAmazonRead(false);
      const latest = await pendingRequests();
      await savePending(latest.filter((candidate) => candidate.requestId !== request.requestId));
      if (openedTabId) {
        try { await chrome.tabs.remove(openedTabId); } catch { /* The helper tab may already be closed. */ }
      }
    }
  }
  } finally { queueProcessing = false; }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_HELPER_STATUS") {
    (async () => {
      const requests = await pendingRequests();
      const statuses = await runStatuses();
      sendResponse({
        ok: true,
        statuses: statuses.sort((left, right) => right.startedAt - left.startedAt),
        remaining: {
          PRICE: requests.filter((request) => request.bulk && requestMode(request) === "PRICE").length,
          TRACKING: requests.filter((request) => request.bulk && requestMode(request) === "TRACKING").length
        },
        open: {
          PRICE: requests.filter((request) => request.bulk && requestMode(request) === "PRICE" && request.destinationTabId !== null).length,
          TRACKING: requests.filter((request) => request.bulk && requestMode(request) === "TRACKING" && request.destinationTabId !== null).length
        }
      });
    })();
    return true;
  }

  if (message?.type === "CANCEL_BULK_REQUESTS") {
    (async () => {
      const mode = ["PRICE", "TRACKING"].includes(message.mode) ? message.mode : null;
      const cancelled = await cancelRuns(sender.tab?.id || null, mode);
      sendResponse({ ok: true, cancelled });
    })();
    return true;
  }

  if (message?.type === "BEGIN_TRACKING_REQUEST" && sender.tab?.id) {
    (async () => {
      const requests = await pendingRequests();
      requests.push({
        requestId: message.requestId,
        sourceTabId: sender.tab.id,
        inputLabel: message.inputLabel,
        orderId: message.orderId,
        amazonUrl: message.amazonUrl,
        destinationTabId: null,
        createdAt: Date.now()
      });
      await savePending(requests);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (message?.type === "BEGIN_BULK_TRACKING_REQUEST" && sender.tab?.id) {
    (async () => {
      const requests = await pendingRequests();
      const existingOrderIds = new Set(requests.map((request) => request.orderId));
      for (const item of message.requests || []) {
        if (!item.orderId || !item.amazonUrl || existingOrderIds.has(item.orderId)) continue;
        requests.push({
          requestId: crypto.randomUUID(),
          sourceTabId: sender.tab.id,
          inputLabel: item.inputLabel,
          orderId: item.orderId,
          amazonUrl: item.amazonUrl,
          destinationTabId: null,
          bulk: true,
          mode: "TRACKING",
          createdAt: Date.now()
        });
      }
      await savePending(requests);
      const queued = requests.filter((request) => request.bulk && request.mode !== "PRICE" && request.sourceTabId === sender.tab.id).length;
      await startRun(sender.tab.id, "TRACKING", queued);
      sendResponse({ ok: true, queued });
      await processBulkQueue(sender.tab.id);
    })();
    return true;
  }

  if (message?.type === "BEGIN_BULK_AMAZON_PRICE_CHECK" && sender.tab?.id) {
    (async () => {
      const requests = await pendingRequests();
      const existingKeys = new Set(requests.filter((request) => request.mode === "PRICE").map((request) => request.requestKey));
      for (const item of message.requests || []) {
        let url;
        try { url = new URL(item.amazonUrl); } catch { continue; }
        const isAmazon = url.protocol === "https:" && (url.hostname === "amazon.com" || url.hostname.endsWith(".amazon.com"));
        if (!isAmazon || !item.requestKey || !item.orderIds?.length || existingKeys.has(item.requestKey)) continue;
        requests.push({
          requestId: crypto.randomUUID(),
          requestKey: item.requestKey,
          sourceTabId: sender.tab.id,
          orderIds: item.orderIds,
          amazonUrl: item.amazonUrl,
          destinationTabId: null,
          bulk: true,
          mode: "PRICE",
          createdAt: Date.now()
        });
      }
      await savePending(requests);
      const queued = requests.filter((request) => request.bulk && request.mode === "PRICE" && request.sourceTabId === sender.tab.id).length;
      await startRun(sender.tab.id, "PRICE", queued);
      sendResponse({ ok: true, queued });
      await processBulkQueue(sender.tab.id);
    })();
    return true;
  }

  if ((message?.type === "TRACKING_FOUND" || message?.type === "TRACKING_NOT_FOUND") && sender.tab?.id) {
    (async () => {
      const requests = await pendingRequests();
      const openerId = sender.tab?.openerTabId;
      const matching = requests
        .filter((request) => request.destinationTabId === sender.tab.id || (openerId && request.sourceTabId === openerId))
        .sort((left, right) => right.createdAt - left.createdAt)[0];
      if (!matching) return sendResponse({ ok: false });
      if (matching.mode === "PRICE") return sendResponse({ ok: false });
      if (message.blocked) { await pauseAmazonWork("Amazon verification required. Checking the existing tab hourly; manual verification may still be needed.", true, sender.tab.id); return sendResponse({ ok: true }); }

      await notifySource(matching, message.type === "TRACKING_FOUND"
        ? { type: "FILL_TRACKING", trackingNumber: message.trackingNumber, carrier: message.carrier, autoSave: !!matching.bulk }
        : { type: "TRACKING_LOOKUP_FAILED", reason: message.reason, autoSave: !!matching.bulk });
      if (matching.bulk) await advanceRun(matching.sourceTabId, "TRACKING", message.type === "TRACKING_FOUND");
      if (matching.bulk) await noteAmazonRead(message.type === "TRACKING_FOUND");
      await savePending(requests.filter((request) => request.requestId !== matching.requestId));
      if (matching.bulk) {
        try { await chrome.tabs.remove(sender.tab.id); } catch { /* The tracking tab may already be closed. */ }
        await processBulkQueue(matching.sourceTabId);
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if ((message?.type === "AMAZON_PRICE_FOUND" || message?.type === "AMAZON_PRICE_NOT_FOUND") && sender.tab?.id) {
    (async () => {
      const requests = await pendingRequests();
      const matching = requests
        .filter((request) => request.mode === "PRICE" && request.destinationTabId === sender.tab.id)
        .sort((left, right) => right.createdAt - left.createdAt)[0];
      if (!matching) return sendResponse({ ok: false });
      if (message.blocked) { await pauseAmazonWork("Amazon verification required. Checking the existing tab hourly; manual verification may still be needed.", true, sender.tab.id); return sendResponse({ ok: true }); }
      await notifySource(matching, message.type === "AMAZON_PRICE_FOUND"
        ? { type: "FILL_AMAZON_PRICE", unitPriceCents: message.unitPriceCents, shippingCents: message.shippingCents, orderIds: matching.orderIds }
        : { type: "AMAZON_PRICE_LOOKUP_FAILED", reason: message.reason, unavailable: Boolean(message.unavailable), orderIds: matching.orderIds });
      await advanceRun(matching.sourceTabId, "PRICE", message.type === "AMAZON_PRICE_FOUND");
      await noteAmazonRead(message.type === "AMAZON_PRICE_FOUND", Boolean(message.unavailable));
      await savePending(requests.filter((request) => request.requestId !== matching.requestId));
      try { await chrome.tabs.remove(sender.tab.id); } catch { /* The product tab may already be closed. */ }
      await processBulkQueue(matching.sourceTabId);
      sendResponse({ ok: true });
    })();
    return true;
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  (async () => {
    const requests = await pendingRequests();
    const request = requests.find((candidate) => candidate.destinationTabId === tabId);
    if (!request) return;
    // chrome.tabs.create("about:blank") can emit a completed event after the
    // request is registered but before navigation reaches Amazon. Never treat
    // that temporary page as a failed Amazon read.
    let pageUrl;
    try { pageUrl = new URL(tab.url || changeInfo.url || ""); } catch { return; }
    if (!(pageUrl.protocol === "https:" && (pageUrl.hostname === "amazon.com" || pageUrl.hostname.endsWith(".amazon.com")))) return;
    if (requestMode(request) === "TRACKING") {
      for (let attempt = 0; attempt < 12; attempt++) {
        try {
          await chrome.tabs.sendMessage(tabId, { type: "INSPECT_AMAZON_TRACKING" });
          return;
        } catch {
          await new Promise((resolve) => setTimeout(resolve, 500));
        }
      }
      return;
    }
    for (let attempt = 0; attempt < 12; attempt++) {
      try {
        await chrome.tabs.sendMessage(tabId, { type: "INSPECT_AMAZON_PRICE" });
        return;
      } catch {
        // document_idle content scripts can start just after the completed
        // navigation event. Retry briefly instead of dropping the check.
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
    }
    const latest = await pendingRequests();
    const failed = latest.find((candidate) => candidate.mode === "PRICE" && candidate.destinationTabId === tabId);
    if (!failed) return;
    await notifySource(failed, {
      type: "AMAZON_PRICE_LOOKUP_FAILED",
      reason: "Amazon opened, but its page reader did not start. Check for an Amazon sign-in or CAPTCHA page, then retry.",
      orderIds: failed.orderIds
    });
    await advanceRun(failed.sourceTabId, "PRICE", false);
    await noteAmazonRead(false);
    await savePending(latest.filter((candidate) => candidate.requestId !== failed.requestId));
    try { await chrome.tabs.remove(tabId); } catch { /* The product tab may already be closed. */ }
    await processBulkQueue(failed.sourceTabId);
  })();
});

chrome.tabs.onCreated.addListener((tab) => {
  if (!tab.id || !tab.openerTabId) return;
  (async () => {
    const requests = await pendingRequests();
    const request = requests
      .filter((candidate) => candidate.sourceTabId === tab.openerTabId && candidate.destinationTabId === null)
      .sort((left, right) => right.createdAt - left.createdAt)[0];
    if (!request) return;
    request.destinationTabId = tab.id;
    await savePending(requests);
  })();
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void (async () => {
    const requests = await pendingRequests();
    const affected = requests.filter((r) => r.bulk && r.destinationTabId === tabId);
    if (!affected.length) return;
    await savePending(requests.map((r) => r.destinationTabId === tabId ? { ...r, destinationTabId: null } : r));
    if (!(await workloadState()).paused) await noteAmazonRead(false);
  })();
});
